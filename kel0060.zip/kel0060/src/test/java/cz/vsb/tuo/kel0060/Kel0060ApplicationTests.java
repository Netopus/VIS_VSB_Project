package cz.vsb.tuo.kel0060;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kel0060ApplicationTests {

	@Test
	void contextLoads() {
	}

}

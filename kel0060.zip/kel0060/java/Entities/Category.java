package Entities;

public class Category {



}

package cz.vsb.tuo.kel0060;

public class Appconfig {
	
	public static final String SQLurl = "jdbc:sqlite:mangasite.db";

}

package cz.vsb.tuo.kel0060.repository;

import java.util.List;

import Entities.Category;

public class CategoryRepository {

	public List<Category> findAllById(List<Integer> categoryIds) {
		// TODO Auto-generated method stub
		return null;
	}


	public void saveAll(List<Entities.Category> categories) {
		// TODO Auto-generated method stub
		
	}

}
